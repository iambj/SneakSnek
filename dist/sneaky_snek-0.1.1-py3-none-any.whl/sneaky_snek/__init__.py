# #watchFolders
# @app.route("/check_changes", methods=["GET", 'POST'])
# def check_changes():
# 	return Handler.handle_request(app, bytes.decode(request.data))
	
# Handler.make_new_shit(app)  #watchFolders